import os
import numpy as np
from flask import Flask, request, render_template, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from werkzeug.utils import secure_filename

# Define a flask app
app = Flask(__name__)

# Model saved with Keras model.save()
MODEL_PATH = 'plant_disease_model_finetuned.h5'

# Load your trained model
model = load_model(MODEL_PATH)
print('Model loaded. Start serving...')

# -----------------------------------------------------------------------------------
# ⚠️ UPDATE THIS LIST with your actual class names in the correct order!
# You can get this from: list(train_generator.class_indices.keys())
# -----------------------------------------------------------------------------------
class_names = [
    'Apple___Apple_scab', 'Apple___Black_rot', 'Apple___Cedar_apple_rust', 'Apple___healthy',
    'Blueberry___healthy', 'Cherry_(including_sour)___Powdery_mildew', 'Cherry_(including_sour)___healthy',
    'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot', 'Corn_(maize)___Common_rust_', 'Corn_(maize)___Northern_Leaf_Blight', 'Corn_(maize)___healthy',
    'Grape___Black_rot', 'Grape___Esca_(Black_Measles)', 'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)', 'Grape___healthy',
    'Orange___Haunglongbing_(Citrus_greening)', 'Peach___Bacterial_spot', 'Peach___healthy',
    'Pepper,_bell___Bacterial_spot', 'Pepper,_bell___healthy', 'Potato___Early_blight', 'Potato___Late_blight', 'Potato___healthy',
    'Raspberry___healthy', 'Soybean___healthy', 'Squash___Powdery_mildew', 'Strawberry___Leaf_scorch', 'Strawberry___healthy',
    'Tomato___Bacterial_spot', 'Tomato___Early_blight', 'Tomato___Late_blight', 'Tomato___Leaf_Mold', 'Tomato___Septoria_leaf_spot',
    'Tomato___Spider_mites Two-spotted_spider_mite', 'Tomato___Target_Spot', 'Tomato___Tomato_Yellow_Leaf_Curl_Virus', 'Tomato___Tomato_mosaic_virus', 'Tomato___healthy'
]

def model_predict(img_path, model):
    # Load the image with the same target size as your model training
    img = image.load_img(img_path, target_size=(224, 224))

    # Preprocessing the image
    x = image.img_to_array(img)
    x = x / 255.0  # Normalize the image (rescale) just like in training
    x = np.expand_dims(x, axis=0)

    # Make prediction
    preds = model.predict(x)
    
    # Get the index of the max probability
    pred_class_index = np.argmax(preds, axis=1)[0]
    
    # Get the class name and probability
    result = class_names[pred_class_index]
    probability = preds[0][pred_class_index]
    
    return result, probability

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    f = request.files['file']

    if f.filename == '':
        return jsonify({'error': 'No selected file'})

    if f:
        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(basepath, 'uploads', secure_filename(f.filename))
        
        # Ensure uploads directory exists
        os.makedirs(os.path.join(basepath, 'uploads'), exist_ok=True)
        
        f.save(file_path)

        # Make prediction
        result, probability = model_predict(file_path, model)
        
        # Format probability as percentage
        prob_percent = f"{probability * 100:.2f}%"

        return jsonify({'result': result, 'probability': prob_percent})

    return None

if __name__ == '__main__':
    app.run(debug=True)

